package com.example.myapplication2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
    private ImageView option;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        option = (ImageView) findViewById(R.id.option);
        option.setOnClickListener(this);

        Toast.makeText(MainActivity.this, "Click anyother on Screen ......",Toast.LENGTH_SHORT).show();



    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.option) {
            option.setVisibility(View.GONE);
            Intent loginIntent = new Intent(MainActivity.this, OptionActivity.class);
            startActivity(loginIntent);

        }


    }
}
